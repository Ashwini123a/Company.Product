﻿using Company.Product.Automation.Common.Wrappers;
using OpenQA.Selenium;
using System;

namespace Company.Product.Automation.Common.Utils
{
    public class LocalDriverBuilder
    {
        private readonly WebDriverFactory _factory;

        internal LocalDriverBuilder(WebDriverFactory factory)
        {
            this._factory = factory;
        }

        public LocalDriverBuilder() : this(new WebDriverFactory())
        {
        }

        public virtual IWebDriver Launch(string browserType, string url)
        {
            var driver = CreateWebDriver("Chrome");
            driver.Navigate().GoToUrl(url);
            return driver;
        }

        private IWebDriver CreateWebDriver(string browserTarget)
        {
            switch (browserTarget)
            {
                case BrowserTarget.chrome:
                    return _factory.CreateLocalChromeDriver();
                case BrowserTarget.ie:
                    return _factory.CreateLocalIEDriver();
                case BrowserTarget.fireFox:
                    return _factory.CreateLocalFirefoxDriver();
                default:
                    throw new NotSupportedException($"{browserTarget} is not supported locale browser Type");
            }

        }


    }
}
