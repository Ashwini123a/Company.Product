﻿using Company.Product.Automation.Common.BaseClasses;
using Company.Product.Automation.Common.Utils;
using Company.Product.Automation.PageRepository.PageObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Threading;

namespace Company.Product.Automation.TestScripts
{

    [TestFixture]
    public class ImportUserTest
    {
        public static IWebDriver _driver;
        LogInPage page = new LogInPage();
        ImportParticipantsPage importPage = new ImportParticipantsPage();

        public void Launch()
        {
            _driver = InitializeDriver();
        }

        public IWebDriver InitializeDriver()
        {
            LocalDriverBuilder builder = new LocalDriverBuilder();
            _driver = builder.Launch(BrowserTarget.chrome, CompanyConstants.url);
            return _driver;
        }

        [Test, Order(1)]
        [Category("Login")]
        public void InValidLoginToPage()
        {

            try
            {
                Launch();
                page.OnDemandLogIn(CompanyConstants.inValidUsername, CompanyConstants.inValidPasword, _driver);
                Assert.IsTrue(page.ValidateLoginErrorMessage());

            }
            catch (Exception ex)
            {
                //code to log the error message 
            }
        }

        [Test, Order(2)]
        public void NavigateToPasswordPageAndVerify()
        {

            try
            {
                page.NavigateToNewPasswordPage();
                bool pageNavigated = page.VerifyNewPasswordPage();
                Assert.IsTrue(pageNavigated);
            }
            catch (System.Exception)
            {
            }

        }

        [Test, Order(3)]
        public void RequestForNewPassword()
        {
            try
            {
                page.OnDemandNewPassword(CompanyConstants.validEmail);
                 Assert.IsTrue(page.ValidateUserMessage()); 
            }
            catch (System.Exception)
            {
            }

        }

        [Test, Order(4)]
        [Category("Login")]
        public void ValidLoginToPage()
        {

            try
            {
                page.OnDemandLogIn(CompanyConstants.validUsername, CompanyConstants.validPasword, _driver);
                //to do // need to write assert??

            }
            catch (Exception ex)
            {
                //code to log the error message 
            }

        }

        HomePage homePage = new HomePage();
        [Test, Order(5)]
        public void NavigateToUsersPageAndVerify()
        {
            try
            {
                homePage.NavigateToUsersPage(_driver);

                Assert.IsTrue(homePage.VerifyUserPage());
                homePage.NavigateToImportParticipantsPage();
            }
            catch (Exception ex)
            {

            }

        }


        [Test, Order(6)]
        public void VerifyImportParticipantsPage()
        {
            try
            {
                Assert.IsTrue(importPage.VerifyImportParticipantsPage(_driver));
            }
            catch
            {

            }

        }


        [Test, Order(7)]
        public void ImportParticipantsAndVerify()
        //todo
        {
            try
            {
                importPage.uploadCSVFile();
                Assert.IsTrue(importPage.ValidateImportUserMessage());
            }
            catch (Exception ex)
            {

            }

        }

    }

}
