﻿
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System; 

namespace Company.Product.Automation.Common.BaseClasses
{
    public abstract class BasePage
    {
        IWebDriver _driver;


        public void ObjectClick(By lookupBy, IWebDriver driver = null, int maxWaitTime = 60)
        {
            if (driver != null) _driver = driver;

            IWebElement element = null;
            try
            {
                element = WaitForElementVisible(lookupBy, maxWaitTime: maxWaitTime);
                if (element != null)
                {
                    Actions action = new Actions(_driver);
                    element.Click();
                }
                else
                {
                    throw new Exception(String.Format("Object   not found to click"));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public IWebElement WaitForElementVisible(By lookupBy, IWebDriver driver = null, int maxWaitTime = 10)
        {
            if (driver != null) _driver = driver;
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(maxWaitTime));
            IWebElement element = null;
            try
            {
                var r = wait.Until(condition =>
                 {
                     if (element != null)
                     {
                         return true;
                     }
                     try
                     {
                         element = _driver.FindElement(lookupBy);
                         if (element != null)
                         {
                             return element.Displayed;
                         }
                         return false;

                     }
                     catch (StaleElementReferenceException)
                     {
                         return false;
                     }

                     catch (NoSuchElementException)
                     {
                         return false;
                     }
                     catch (Exception ex)
                     {
                         return false;
                     }
                 });


            }
            catch (Exception ex)
            {
                element = null;
            }
            return element;
        }

        public void SetValueToObject(By lookupBy, string strInputValue, IWebDriver driver = null, int maxWaitTime = 60)
        {
            if (driver != null)
            {
                _driver = driver;
            }

            IWebElement element = null;
            try
            {
                element = WaitForElementVisible(lookupBy, maxWaitTime: maxWaitTime);
                if (element != null)
                {
                    element.Clear();
                    element.SendKeys(strInputValue);
                }
                else
                {
                    throw new Exception("Object not found to Set value");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        public bool validateResultMessage(By lookupBy, string message)
        {

            bool exist = _driver.FindElement(lookupBy).GetAttribute("innerHTML").Contains(message);
            return exist;
        }
        public bool ValidateMessage(By lookupBy, string message)
        {

            bool resultType = false;
            try
            {
                //String script = "document.getElementById('fileName').value='" + "C:\\\\temp\\\\file.txt" + "';";
                //((IJavaScriptExecutor)_driver).ExecuteScript(script);

                //IJavaScriptExecutor javascript = Driver as IJavaScriptExecutor;


                //string text = _driver.FindElement(By.XPath("//*[@id='body - container']/div/div/section/div[2]/text()[3]")).GetAttribute("text");
                //if (text == message)
                //{

                //}


                resultType = ValidateIfExists(lookupBy, message);
                if (resultType == true)
                {
                    var element = _driver.FindElement(lookupBy);
                    if (element.Text == message)
                    {
                        return resultType = true;

                    }
                    else return resultType = false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return resultType;
        }

        private bool ValidateIfExists(By lookupBy, string objectName, int maxWaitTime = 30)
        {
            IWebElement element = null;
            try
            {
                element = WaitForElementVisible(lookupBy, maxWaitTime: maxWaitTime);
                if (element != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch
            {
                return false;
            }
        }


    }
}
