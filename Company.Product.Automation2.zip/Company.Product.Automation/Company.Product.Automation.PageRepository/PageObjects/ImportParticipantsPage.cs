﻿using Company.Product.Automation.Common.BaseClasses;
using Company.Product.Automation.Common.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace Company.Product.Automation.PageRepository.PageObjects
{
    public class ImportParticipantsPage : BasePage
    {
        IWebDriver _driver;
 
        By buttonBrowse
        {
            get { return By.XPath("//*[contains(text(),'Browse')]"); }
        }

        By buttonUpload
        {
            get { return By.XPath("//input[@type='file']"); }
        }

        By buttonImport
        {
            get { return By.Id("edit-submit"); }
        }

        By messageOfImportUser
        {
            get { return By.XPath("//div[@class='alert alert-block alert-success']"); }
        }

        public bool VerifyImportParticipantsPage(IWebDriver driver)
        {
            if (driver != null) _driver = driver;
            bool activeLink = false;
            var element = WaitForElementVisible(buttonBrowse, driver);
            if (element != null)
            {
                activeLink = true;
            }
            return activeLink;
        }

        public void uploadCSVFile()
        {
            try
            {
                var element = WaitForElementVisible(buttonUpload);
                element.SendKeys(CompanyConstants.filePath);
                ObjectClick(buttonImport);
                WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromMilliseconds(3000));
            }
            catch (System.Exception ex)
            {

            }

        }

        public bool ValidateImportUserMessage()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);              
            bool result = validateResultMessage(messageOfImportUser, CompanyConstants.importUserMessage);
            return result;
        }

    }
}
