﻿using Company.Product.Automation.Common.BaseClasses; 
using OpenQA.Selenium; 

namespace Company.Product.Automation.PageRepository.PageObjects
{
    public class HomePage : BasePage
    {
        By linkPeople
        {
            get
            {
                return By.XPath("//*[contains(text(),'People ')]");
            }
        }

        By linkUsers
        {
            get
            {
                return By.XPath("//*[contains(text(),'Users')]");
            }
        }

        By linkUserPage
        {
            get
            {
                return By.LinkText("Add user");
            }
        }

        By linkImportParticipants
        {
            get
            {
                return By.XPath("//*[contains(text(),'Import Participants')]");
            }
        }

        public void NavigateToUsersPage(IWebDriver driver)
        {
            ObjectClick(linkPeople, driver);
            ObjectClick(linkUsers);
        }

        public bool VerifyUserPage()
        {
            bool activeLink = false;
            var element = WaitForElementVisible(linkUserPage);
            if (element != null)
            {
                activeLink = true;
            }
            return activeLink;
        }

        public void NavigateToImportParticipantsPage() 
        {
            ObjectClick(linkImportParticipants); 
        }

    }
}
