﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Company.Product.Automation.TestScripts;
using System;
using System.Collections.Generic;
using System.Text;
