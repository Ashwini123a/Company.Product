﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System.IO;
using System.Reflection;

namespace Company.Product.Automation.Common.Wrappers
{
    internal class WebDriverFactory
    {
        public virtual IWebDriver CreateLocalChromeDriver()
        {
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.SetLoggingPreference(LogType.Browser, LogLevel.All);
            return new ChromeDriver(Directory.GetParent(Assembly.GetEntryAssembly().Location).ToString(),chromeOptions);
        }

        public virtual IWebDriver CreateLocalIEDriver()
        {
            var options = new InternetExplorerOptions();
            options.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
            options.EnsureCleanSession = true;
            options.EnableNativeEvents = true;
            return new InternetExplorerDriver(Directory.GetParent(Assembly.GetEntryAssembly().Location).ToString(), options);
        }

        public virtual IWebDriver CreateLocalFirefoxDriver()
        {
            FirefoxOptions p = new FirefoxOptions();
            p.SetLoggingPreference(LogType.Browser, LogLevel.All);
            return new FirefoxDriver(Directory.GetParent(Assembly.GetEntryAssembly().Location).ToString(), p);

        }


    }
}
