﻿using System;
using System.Collections.Generic;
using System.Text;
using Company.Product.Automation.Common.Utils;
using OpenQA.Selenium;
using Microsoft.Extensions.Configuration;
using NUnit.Framework;

namespace Company.Product.Automation.Common.BaseClasses
{

    //public abstract class BaseTest
    //{
    //    public static IWebDriver _driver;
    //    protected LocalDriverBuilder builder;
    //    protected string url;
    //    protected string startTime;
    //    protected string targetBrowser;
    //    protected IConfiguration configurationManager;

      

    
    //    //[SetUp]
    //    //public void Launch()
    //    //{
    //    //    _driver = InitializeDriver();
    //    //}
    //    //public IWebDriver InitializeDriver()
    //    //{
    //    //    LocalDriverBuilder builder = new LocalDriverBuilder();
    //    //    this.url = CompanyConstants.url;
    //    //    _driver = builder.Launch(targetBrowser, this.url);
    //    //    return _driver;
    //    //}

    //}
}
