﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Company.Product.Automation.Common.Utils
{
    class CommonUtil
    {
    }
}
