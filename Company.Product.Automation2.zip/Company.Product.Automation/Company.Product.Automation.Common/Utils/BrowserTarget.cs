﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace Company.Product.Automation.Common.Utils
{
    public static class BrowserTarget
    {
        public const string chrome = "Chrome";
        public const string ie = "IE";
        public const string safari = "Safari";
        public const string fireFox = "FireFox";
        public const string browserStackiOSSafari = "BrowserStackiOSSafari"; 

    }

    public static class CompanyConstants
    {
        public const string url = "https://ondemand.questionmark.com/home/406121";
        public const string inValidUsername = "test";
        public const string inValidPasword = "testPass";
        public const string validUsername = "qatestuser";
        public const string validPasword = "RNNrq5dubcCNKtBwhALO";
        public const string loginErrorMessage = "Sorry, unrecognized username or password.";
        public const string newPasswordResultMessage = "Further instructions have been sent to your e-mail address.";
        public const string importUserMessage = "1 user";
        public const string validEmail = "aswinipasham.prabhakar@gmail.com";
        public const string filePath = @"C:\MyProjects\Company.Product.Automation\Company.Product.Automation.Data\TestData\Participants.csv";
    }
}
