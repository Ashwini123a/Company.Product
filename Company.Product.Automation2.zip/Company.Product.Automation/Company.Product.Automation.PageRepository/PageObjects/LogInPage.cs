﻿using Company.Product.Automation.Common.BaseClasses;
using Company.Product.Automation.Common.Utils;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace Company.Product.Automation.PageRepository.PageObjects
{
    public class LogInPage : BasePage
    {
        By linkNewPassword
        {
            get
            {
                return By.LinkText("Request new password");
            }
        }

        By UserNameText
        {
            get { return By.Id("edit-name"); }
        }

        By EmailNewPasswordButton
        {
            get { return By.Id("edit-submit"); }
        }
 
        By PasswordText
        {
            get { return By.Id("edit-pass"); }
        }

        By LoginButton
        {
            get { return By.Id("edit-submit"); }
        }

        By LoginValidationErrorMessage
        {
            get { return By.XPath("//div[@class='alert alert-block alert-danger']"); }
        }

        By messageOfEmailUser 
        {
            get { return By.XPath("//div[@class='alert alert-block alert-success']"); }
        }

        //Behaviourial method
        public void OnDemandLogIn(string userName, string userPassword, IWebDriver driver)
        {
            SetValueToObject(UserNameText, userName, driver);
            SetValueToObject(PasswordText, userPassword);
            ObjectClick(LoginButton);
            Thread.Sleep(120);
        }

        public bool ValidateLoginErrorMessage()
        {
            bool result = validateResultMessage(LoginValidationErrorMessage, CompanyConstants.loginErrorMessage);
            return result;
        }

        public void NavigateToNewPasswordPage()
        {
            ObjectClick(linkNewPassword);
        }

        public bool VerifyNewPasswordPage()
        {
            bool activeLink = false;
            var element = WaitForElementVisible(EmailNewPasswordButton);
            if (element != null)  activeLink = true;
            return activeLink;
        }

        public void OnDemandNewPassword(string userName)
        {
            SetValueToObject(UserNameText, userName);
            ObjectClick(EmailNewPasswordButton);
        }

        public bool ValidateUserMessage()
        { 
            bool result = validateResultMessage(messageOfEmailUser, CompanyConstants.newPasswordResultMessage);
            return result;
        }
    }
}
